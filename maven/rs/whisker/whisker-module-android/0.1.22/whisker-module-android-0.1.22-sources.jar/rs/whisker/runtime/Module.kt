// `Module` base class (Android) — the API a Whisker module
// subclasses. `@WhiskerModule` is the explicit registration signal;
// KSP validates the annotated class and emits its registration.
//
// ```kotlin
// import rs.whisker.runtime.Module        // ← explicit import: bare
//                                         //   `Module` would resolve
//                                         //   to java.lang.Module
//
// @WhiskerModule
// class VideoModule : Module() {
//     override fun definition() = ModuleDefinition {
//         Name("Video")
//         View("whisker-video:Video", VideoView::class.java) {
//             Prop("src") { view: VideoView, value ->
//                 view.setSrc(value.asString() ?: "")
//             }
//             Command("play") { view: VideoView, _ -> view.play() }
//         }
//     }
// }
// ```

package rs.whisker.runtime

public abstract class Module {
    /**
     * Authors override to declare the module via the DSL. Default
     * impl returns an empty definition — useful for tests and as a
     * sentinel.
     */
    public open fun definition(): ModuleDefinition = ModuleDefinition(emptyList())

    /**
     * Cached [definition] value — computed lazily on first access so
     * subclasses can do expensive setup in `definition()` without
     * paying for it on every call.
     */
    public val definitionLazy: ModuleDefinition by lazy { definition() }

    /**
     * Fully-qualified module name (`<crate>:<Name>`), set by the
     * KSP-generated registration call. `null` until registered —
     * `sendEvent` silently no-ops in that window. Authors must NOT
     * set this themselves; the KSP processor does. (Public-set
     * rather than `internal set` because the generated
     * `<Module>Behaviors.kt` lives in the consumer Gradle module,
     * not in `rs.whisker.runtime`, so `internal` is out of reach.)
     */
    public var qualifiedName: String? = null

    /**
     * Module-host context. Mirrors Expo's `Module.appContext`.
     * Read `appContext.currentActivity` to reach the host Activity
     * from inside an `OnStartObserving` / `Function` body — the
     * accessor is request-time, so a config-change rotation
     * transparently resolves to the new Activity once the new
     * `WhiskerView` attaches.
     */
    public val appContext: WhiskerAppContext
        get() = WhiskerAppContext.shared

    /**
     * Dispatch [payload] to every Rust subscriber of [event] on this
     * module. The bridge fans the call out to every
     * `PlatformModule::on_event` callback registered against
     * `(this.qualifiedName, event)`.
     *
     * Defaults to [WhiskerValue.Null] for an unparameterised ping.
     * No-op if the module hasn't been registered yet.
     */
    public fun sendEvent(event: String, payload: WhiskerValue = WhiskerValue.Null) {
        val qname = qualifiedName ?: return
        if (event !in definitionLazy.events || !payload.isData()) return
        WhiskerModuleEventCenter.dispatchSend(qname, event, payload)
    }

    /**
     * Fire every `OnStartObserving("eventName")` hook on this
     * module. Called by [WhiskerModuleEventCenter] when the JNI
     * trampoline routes a bridge start event back here. Public so
     * the center (a different file) can dispatch into it; authors
     * should not call this directly.
     */
    public fun fireOnStartObserving(eventName: String) {
        for (h in definitionLazy.onStartObservingHooks) {
            if (h.eventName == eventName) h.handler()
        }
    }

    /** Counterpart to [fireOnStartObserving]. */
    public fun fireOnStopObserving(eventName: String) {
        for (h in definitionLazy.onStopObservingHooks) {
            if (h.eventName == eventName) h.handler()
        }
    }
}
